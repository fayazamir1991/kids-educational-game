# Animal recordings included in the Android product

## cow

Cow moos — Joseph SARDIN

Source: https://bigsoundbank.com/cow-moos-s0546.html
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/andlo/ovos-skill-sound-like/blob/77d00889839d6e13af953bf0ee70afb067852aa1/CREDITS.md
Processing: Trimmed; 60 Hz rumble filter; loudness normalized to -20 LUFS / -3 dBTP; 25/80ms fades; 50ms leading and 150ms trailing silence; mono 44.1 kHz MP3 128 kbps. No sound synthesis.
Final SHA256: f6b976eb8f01b5a622d6429fd14524ee1c6315ce4813790f23a75aba98d2971c

## sheep

Sheep_in_field.aiff — zwier

Source: https://www.freesound.org/people/zwier/sounds/200329/
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/karolpiczak/ESC-50/blob/33c8ce9eb2cf0b1c2f8bcf322eb349b6be34dbb6/LICENSE
Processing: Selected a short high-target-event window using fallible YAMNet semantic screening; not claimed as human listening. Trimmed, 60Hz rumble filter, normalized -20LUFS/-3dBTP, 25/60ms fade,50ms leading and100ms trailing silence, mono44.1kHz MP3/128kbps. No animal voice synthesis or pitch shifting.
Final SHA256: 526f4c7eb6e10be93c24310719a7cda42d3350a27a533d3ca8353464a60d4765

## crow

Crows_01.wav — Q.K.

Source: https://www.freesound.org/people/Q.K./sounds/56233/
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/karolpiczak/ESC-50/blob/33c8ce9eb2cf0b1c2f8bcf322eb349b6be34dbb6/LICENSE
Processing: Selected a short high-target-event window using fallible YAMNet semantic screening; not claimed as human listening. Trimmed, 60Hz rumble filter, normalized -20LUFS/-3dBTP, 25/60ms fade,50ms leading and100ms trailing silence, mono44.1kHz MP3/128kbps. No animal voice synthesis or pitch shifting.
Final SHA256: 851d72ff3f449951d6d4ece9be77ea61adb4622c8377706b3ef990f3b5fe7f5b

## lion

Lion raring-sound1TamilNadu178.ogg — male lion roaring in captivity — த*உழவன் (Commons user தகவலுழவன்)

Source: https://commons.wikimedia.org/wiki/File:Lion_raring-sound1TamilNadu178.ogg
License: Public domain (PD-self) (https://commons.wikimedia.org/wiki/Template:PD-self)
Evidence: https://commons.wikimedia.org/w/index.php?title=File%3ALion_raring-sound1TamilNadu178.ogg&oldid=1050777795
Processing: Selected a short target-event window from a documented natural recording; 60Hz rumble filter; normalized -20 LUFS / -3 dBTP; 25/80ms fades; 50ms leading and 100ms trailing silence; mono 44.1kHz MP3 / 128kbps. No voice synthesis, pitch shifting or repetition. Exact final MP3 screened with pinned Google YAMNet; not human listening.
Final SHA256: da745ea62c22e5c1b6197357794289fbfc73816432dce507ae2480dace58fee0

## fly

flys-I.wav — galeku

Source: https://freesound.org/people/galeku/sounds/46938/
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/karolpiczak/ESC-50/blob/33c8ce9eb2cf0b1c2f8bcf322eb349b6be34dbb6/LICENSE
Processing: Selected recorded excerpt; gentle fade-in/out; loudness normalized to -20 LUFS / -3 dBTP; mono 44.1 kHz MP3 128 kbps. No animal sound synthesis.
Final SHA256: 989efc08094b07a5e1dd931c01f006ee07a2076a6ff5ac04a76efc7bd5c62be2

## bee

Bees, honeybees — a swarm buzzing among flowers (Apis mellifera) — YleArkisto / Finnish Broadcasting Company Yle Archives

Source: https://www.freesound.org/people/YleArkisto/sounds/263673/
License: CC-BY-3.0 (https://creativecommons.org/licenses/by/3.0/)
Evidence: https://commons.wikimedia.org/w/index.php?title=File%3A263673_ylearkisto_mehilainen-tarhamehilainen-parvi-bees-honeybees-a-swarm-of-bees-buzzing-among-the-flowers-apis-mellifera.wav&oldid=1187049516
Processing: Selected a short target-event window from a documented natural recording; 60Hz rumble filter; normalized -20 LUFS / -3 dBTP; 25/80ms fades; 50ms leading and 100ms trailing silence; mono 44.1kHz MP3 / 128kbps. No voice synthesis, pitch shifting or repetition. Exact final MP3 screened with pinned Google YAMNet; not human listening.
Final SHA256: dda8d0c3d2c76057179bc1967e2b414575dcaacd7cfa44dadfa78f0727dcab4a

## rooster

Rooster song — Joseph SARDIN

Source: https://bigsoundbank.com/detail-0283-rooster-song.html
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/andlo/ovos-skill-sound-like/blob/77d00889839d6e13af953bf0ee70afb067852aa1/CREDITS.md
Processing: Trimmed; 60 Hz rumble filter; loudness normalized to -20 LUFS / -3 dBTP; 25/80ms fades; 50ms leading and 150ms trailing silence; mono 44.1 kHz MP3 128 kbps. No sound synthesis.
Final SHA256: 94f3cac1f3c5fac7d55f0645f32898adad7ca8ddb5955e624573620fda1c324f

## hen

chicken_chatter.aif — jsbarrett

Source: https://freesound.org/people/jsbarrett/sounds/200330/
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/karolpiczak/ESC-50/blob/33c8ce9eb2cf0b1c2f8bcf322eb349b6be34dbb6/LICENSE
Processing: Selected a short high-target-event window using fallible YAMNet semantic screening; not claimed as human listening. Trimmed, 60Hz rumble filter, normalized -20LUFS/-3dBTP, 25/60ms fade,50ms leading and100ms trailing silence, mono44.1kHz MP3/128kbps. No animal voice synthesis or pitch shifting.
Final SHA256: fc88d664e8daabc9fad71ee84ff9f2d8b3ffe5978cfae51c016f4644893dbe6f

## horse

Horse neighing 3 — Joseph SARDIN

Source: https://bigsoundbank.com/horse-neighing-3-s0863.html
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/andlo/ovos-skill-sound-like/blob/77d00889839d6e13af953bf0ee70afb067852aa1/CREDITS.md
Processing: Selected recorded excerpt; gentle fade-in/out; loudness normalized to -20 LUFS / -3 dBTP; mono 44.1 kHz MP3 128 kbps. No animal sound synthesis. Removed the source mirror's 1.4-second silent tail for immediate replay readiness.
Final SHA256: f0fe8c7bb42fc8dac945ecb2c03da06a8b84192627233fdd9f39e94ec5af6ecf

## dog

2 dogs barking — Joseph SARDIN

Source: https://bigsoundbank.com/2-dogs-barking-s0868.html
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/andlo/ovos-skill-sound-like/blob/77d00889839d6e13af953bf0ee70afb067852aa1/CREDITS.md
Processing: Trimmed; 60 Hz rumble filter; loudness normalized to -20 LUFS / -3 dBTP; 25/80ms fades; 50ms leading and 150ms trailing silence; mono 44.1 kHz MP3 128 kbps. No sound synthesis.
Final SHA256: ade50e20ab6d0a20b2a7b199e5db231f0f59d164282834771efb0604ce222cd6

## cat

Meow cat 1 — Joseph SARDIN

Source: https://bigsoundbank.com/detail-1889-meow-cat-1.html
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/andlo/ovos-skill-sound-like/blob/77d00889839d6e13af953bf0ee70afb067852aa1/CREDITS.md
Processing: Selected a short high-target-event window using fallible YAMNet semantic screening; not claimed as human listening. Trimmed, 60Hz rumble filter, normalized -20LUFS/-3dBTP, 25/60ms fade,50ms leading and100ms trailing silence, mono44.1kHz MP3/128kbps. No animal voice synthesis or pitch shifting.
Final SHA256: 565a12e7d064e221f89e657e2669dcb38ab2fc0be6f7c98132790fba4b3526b4

## duck

Ducks — Joseph SARDIN

Source: https://bigsoundbank.com/detail-0276-ducks.html
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/andlo/ovos-skill-sound-like/blob/77d00889839d6e13af953bf0ee70afb067852aa1/CREDITS.md
Processing: Trimmed; 60 Hz rumble filter; loudness normalized to -20 LUFS / -3 dBTP; 25/80ms fades; 50ms leading and 150ms trailing silence; mono 44.1 kHz MP3 128 kbps. No sound synthesis.
Final SHA256: 8623c55be726aec313bccca6007ceaab8a073ac5141f5d238404e6c6d6c3ef02

## pig

Pig_Grunts_Snorts_Breathing_Hackney_City_Farm.wav — tompallant

Source: https://www.freesound.org/people/tompallant/sounds/257858/
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/karolpiczak/ESC-50/blob/33c8ce9eb2cf0b1c2f8bcf322eb349b6be34dbb6/LICENSE
Processing: Selected a short high-target-event window using fallible YAMNet semantic screening; not claimed as human listening. Trimmed, 60Hz rumble filter, normalized -20LUFS/-3dBTP, 25/60ms fade,50ms leading and100ms trailing silence, mono44.1kHz MP3/128kbps. No animal voice synthesis or pitch shifting.
Final SHA256: 6966830ebb0941bd0063efb17e0e693d30865225fb492d42e22ce6f68cdc359e

## frog

Frogs 1 — Joseph SARDIN

Source: https://bigsoundbank.com/frogs-1-s0997.html
License: CC0-1.0 (https://creativecommons.org/publicdomain/zero/1.0/)
Evidence: https://github.com/andlo/ovos-skill-sound-like/blob/77d00889839d6e13af953bf0ee70afb067852aa1/CREDITS.md
Processing: Selected a short high-target-event window using fallible YAMNet semantic screening; not claimed as human listening. Trimmed, 60Hz rumble filter, normalized -20LUFS/-3dBTP, 25/60ms fade,50ms leading and100ms trailing silence, mono44.1kHz MP3/128kbps. No animal voice synthesis or pitch shifting.
Final SHA256: f3cfeb5f159a353c4aba663ee7a1007aab0cf46acc750194d1777ff01241a8b6
